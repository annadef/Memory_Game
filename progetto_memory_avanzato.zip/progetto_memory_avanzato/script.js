const immagini = ["amare.png", "amare1.png", "arrabbiato.png", "bello.png", "piangere.png", "ridere.png", "shock.png", "spavento.png"];
const allImmagini = [...immagini, ...immagini];
const used = [];
var tuttiIClick = 0;
var clickImgs = [];
var clicking = false;

function mostraImg(id) {
    if (!clicking) {
        clicking = true;

if (clickImgs.length < 2) {
            $("#clicks").html(tuttiIClick++);
            $("#emoji" + id + " img").show();
            clickImgs.push(id);
        }

if (clickImgs.length === 2) {
            if ($("#emoji" + clickImgs[0]).html() !== $("#emoji" + clickImgs[1]).html()) {
                setTimeout(() => {
                    $("#emoji" + clickImgs[0] + " img").hide();
                    $("#emoji" + clickImgs[1] + " img").hide();
                    clickImgs = [];
                    clicking = false;
                }, 1000);
            } else {
                clickImgs = [];
                clicking = false;
            }
        } else {
            clicking = false;
        }
    }
}

$("document").ready(function() {
    $(".images").each((index, img) => {

let random1 = Math.floor(Math.random() * allImmagini.length);

$(img).append($('<img src="img/' + allImmagini[random1] + '">'));

allImmagini.splice(random1, 1);
    });
});